public enum UIPanelTypes
{
    Start,
    Level,
    Win,
    Fail
}
