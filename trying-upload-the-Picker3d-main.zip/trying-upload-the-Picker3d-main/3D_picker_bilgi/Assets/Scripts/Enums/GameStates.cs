namespace Enums{
    
    public enum GameStates
    {
        Idle,
        Moving,
        Final

    }
}