﻿/*
 * BinaryWriter is not implemented.
 * See this post for more info: https://moodkie.com/forum/viewtopic.php?p=7478#p7478
 */
